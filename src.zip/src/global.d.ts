declare interface Page {
  name: string;
  url: string;
}
