function setCurrentRecord({
  event,
  argument,
}: {
  event: Event;
  argument: number;
}): number {
  return argument;
}
